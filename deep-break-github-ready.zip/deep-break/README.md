# Deep Break — Coming soon

صفحة "قريباً" ثابتة (HTML/CSS/JS بدون أي مكتبات) فيها عدّاد تنازلي لـ 30 نوفمبر 2026 ونموذج تسجيل بالإيميل.

## تعديل الموعد
في `index.html` ابحث عن `2026-11-30T00:00:00` وغيّره.

## نموذج الإيميل
الزرار بيفتح تطبيق البريد (`mailto:`) ويبعت لإيميل الاستلام المكتوب في `index.html`. لتجميع الإيميلات تلقائياً استخدم خدمة نماذج (Formspree / Google Forms).

## النشر على GitHub Pages
- **الأسهل:** Settings ← Pages ← Source: `Deploy from a branch` ← `main` / `(root)`.
- **تلقائي:** Source: `GitHub Actions` (الـ workflow موجود في `.github/workflows/pages.yml`).

الرابط: `https://<username>.github.io/<repo-name>/`
